
from random import choice
from utils import EMPTYCELL, corners, sides, formatBoard, isAvailable, marksAtIndices, possibleWinners, oppositeCorner, \
                  otherMark, setMove, theWinner, validMoves

class Player:
    """
    The board is numbered as follows.
    0 1 2
    3 4 5
    6 7 8
    """

    def __init__(self, gameManager, myMark: str) -> None:
        self.gameManager = gameManager
        # self.possibleMoves = list(range(9))  # 9 possible moves
        # self.possibleWinners = gameManager.possibleWinners
        # self.corners = [0, 2, 6, 8]
        # self.sides = [1, 3, 5, 7]

        self.myMark = myMark
        self.opMark = otherMark(myMark)

        self.sarsList = []
        self.prevBoardMove = None

        self.qTable = gameManager.qTable

        self.typeName = type(self).__name__

    def finalReward(self, reward: float):
        """
        This is called after the game is over to inform the player of its final reward.
        :param reward: The final reward for the game.
        # :param finalBoard: The final board of the game.
        :return: None
        """
        (board, move) = self.prevBoardMove
        # There is no nextBoard
        self.sarsList.append((board, move, reward, None))
        return self.sarsList

    def makeAMove(self, reward: float, board: str) -> int:
        """
        Called by the GameManager to get this player's move.
        :param reward:
        :param board:
        :return: A move
        """
        move = self._makeAMove(board)
        self.updateSarsList(reward, board, move)
        return move

    def _makeAMove(self, board: str) -> int:
        move = choice(validMoves(board))
        return move

    def updateSarsList(self, reward: float, curBoard: str, curMove: int) -> None:
        if self.prevBoardMove is not None:
            (board, move) = self.prevBoardMove
            self.sarsList.append((board, move, reward, curBoard))
        self.prevBoardMove = (curBoard, curMove)


class HumanPlayer(Player):

    def _makeAMove(self, board: str):
        print(f'\n{formatBoard(board)}')
        c = '-1'
        while c not in "012345678" or len(c) != 1 or not isAvailable(board, int(c)):
            c = input(f'{self.myMark} to move > ')
        move = int(c)
        return move


class LearningPlayer(Player):

    def _makeAMove(self, board: str) -> int:
        """
        Update qValues and select a move based on representative board from this board's equivalence class.
        Should not be random like the following.
        """
        # Either a random move or the move with the highest QValue for this state.
        move = (self.qTable.getBestMove(self.typeName, board) if self.gameManager.is_test_game() else
                choice(validMoves(board))
                )
        return move


class WinsBlocksCornersPlayer(Player):

    def _makeAMove(self, board: str) -> int:
        (myBlocks, myWins, availCorners) = self.winsBlocksCorners(board)
        move = choice(myWins if myWins else
                      myBlocks if myBlocks else
                      availCorners if availCorners else
                      validMoves(board)
                     )
        return move

    def winsBlocksCorners(self, board: str) -> [[int]]:
        myWins = set()
        myBlocks = set()
        emptyCell = EMPTYCELL
        for possWin in possibleWinners:
            marks = marksAtIndices(board, possWin)
            if marks.count(emptyCell) == 1:
                if marks.count(self.myMark) == 2:
                    myWins.add(possWin[marks.index(emptyCell)])
                if marks.count(self.opMark) == 2:
                    myBlocks.add(possWin[marks.index(emptyCell)])
        # pick the center or a corner if available.
        availableCornersAndCenter = [pos for pos in corners + [4] if isAvailable(board, pos)]
        return (list(myBlocks), list(myWins), availableCornersAndCenter)


class HardWiredPlayer(WinsBlocksCornersPlayer):

    def _makeAMove(self, board: str) -> int:
        """
        If this player can win, it will.
        If not, it blocks if the other player can win.
        Otherwise it makes a random valid move.
        :param board:
        :return: selected move
        """

        (myBlocks, myWins, availCorners) = self.winsBlocksCorners(board)
        move = choice(myWins if myWins else
                      myBlocks if myBlocks else
                      availCorners if availCorners else
                      [self.otherMove(board, board.count(EMPTYCELL))]
                      )
        return move

    @staticmethod
    def otherMove(board, emptyCellsCount) -> int:
        """
        Special case moves.
        :param board:
        :param emptyCellsCount:
        :return: Selected move
        """
        # The following is for X's second move. It applies only if X's first move was to a corner.
        if emptyCellsCount == 7 and board.index('X') in corners:
            oFirstMove = board.index('O')
            # If O's first move is a side cell, X should take the center.
            # Otherwise, X should take the corner opposite its first move.
            if oFirstMove in sides:
                return 4
            if oFirstMove == 4:
                opCorner = oppositeCorner(board.index('X'))
                return opCorner
        # If this is O's second move and X has diagonal corners, O should take a side move.
        availableCorners = [i for i in corners if isAvailable(board, i)]
        # If X has two adjacent corners O was forced to block (above). So, if there are 2 available corners
        # they are diagonal.
        if emptyCellsCount == 6 and len(availableCorners) == 2:
            return choice([pos for pos in sides if isAvailable(board, pos)])
        # If none of the special cases apply, take a corner if available, otherwise the center, otherwise any valid move.
        return (choice(availableCorners) if len(availableCorners) > 0 else
                4 if isAvailable(board, 4) else
                validMoves(board)
                )


class MinimaxPlayer(HardWiredPlayer):

    def _makeAMove(self, board: str) -> int:
        # The first few moves are hard-wired into HardWiredPlayer.
        move = (super()._makeAMove(board) if board.count(EMPTYCELL) >= 7 else
        # minimax returns (val, move, count). Extract move.
                self.minimax(board)[1])
        return move

    def makeAndEvaluateMove(self, board: str, move: int, mark: str, count: int):
        """
        Make the move and evaluate the board.
        :param board:
        :param move:
        :param mark:
        :param count: A longer game is better.
        :return: 'X' is maximizer; 'O' is minimizer
        """
        boardCopy = setMove(board, move, mark)
        winner = theWinner(boardCopy)
        (val, count1) = ( ( 1, count) if winner == 'X' else
                         (-1, count) if winner == 'O' else
                         # winner == None. Is the game a tie because board is full?
                         ( 0, count) if boardCopy.count(EMPTYCELL) == 0 else
                         # The game is not over.
                         (lambda mmResult=self.minimax(boardCopy, count):
                                                      (mmResult[0], mmResult[2])) ( )
                       )
        return (val, move, count1)

    def minimax(self, board: str, count=0) -> (int, int, int):
        """
        Does a minimax search.
        :param board:
        :param count: longest count is better.
        :return: best minimax (val, move, count) with longest count for current player.
        """
        mark = self.gameManager.whoseTurn(board)['mark']
        # possMoves are [(val, move, count)] (val in [1, 0, -1]) for move in self.validMoves(board)]
        possMoves = [self.makeAndEvaluateMove(board, move, mark, count+1) for move in validMoves(board)]
        minOrMax = max if mark == 'X' else min
        (bestVal, _, _) = minOrMax(possMoves, key=lambda possMove: possMove[0])
        bestMoves = [(val, move, count) for (val, move, count) in possMoves if val == bestVal]
        (_, _, longestBestMoveCount) = max(bestMoves, key=lambda possMove: possMove[2])
        # Get all moves with best val and with longest count
        longestBestMoves = [(val, move, count) for (val, move, count) in bestMoves if count == longestBestMoveCount]
        return choice(longestBestMoves)

