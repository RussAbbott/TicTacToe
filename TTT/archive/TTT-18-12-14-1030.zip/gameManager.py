
# noinspection PyUnresolvedReferences
import random

from players import HumanPlayer, LearningPlayer, MinimaxPlayer, PrettyGoodPlayer, ValidMovePlayer

class GameManager:

    def __init__(self, xPlayerClass, oPlayerClass):
        self.emptyCell =  '.'
        self.majDiag = [0, 4, 8]
        self.minDiag = [2, 4, 6]

        getRowAt = self.getRowAt
        getColAt = self.getColAt
        # These are the eight three-element sequences that could make a win.
        self.possibleWinners = [self.majDiag, self.minDiag,
                                getRowAt(0), getRowAt(3), getRowAt(6),
                                getColAt(0), getColAt(1), getColAt(2)]

        self.transformer = TransformableBoard()

        # Create the players and tell them which side they are playing.
        # The reward field is the reward to pass to the player on its next move.
        self.X = {'mark': 'X', 'reward': 0, 'player': xPlayerClass(self, 'X')}
        self.O = {'mark': 'O', 'reward': 0, 'player': oPlayerClass(self, 'O')}


    @staticmethod
    def formatBoard(board):
        boardStr = [str(x) for x in board]
        boardString = '\n'.join(["-----", ' '.join(boardStr[0:3]), ' '.join(boardStr[3:6]), ' '.join(boardStr[6:9]), "-----"])
        return boardString

    @staticmethod
    def getColAt(move):
        """
        Return a list of the indices for the column that includes move.
        :param move:
        :return:
        """
        colStart = move % 3
        col = [colStart, colStart+3, colStart+6]
        return col

    @staticmethod
    def getRowAt(move):
        """
        Return a list of the indices for the row that includes move.
        :param move:
        :return:
        """
        rowStart = (move//3) * 3
        row = [rowStart, rowStart+1, rowStart+2]
        return row

    def initialBoard(self):
        return list(self.emptyCell * 9)


    def main(self):
        self.mainLoop()

    def mainLoop(self):
        board = list(self.emptyCell * 9)

        # 'X' will make the first move. We switch players at the top of the loop below.
        currentPlayer = self.O
        done = False
        winner = None
        while not done:
            currentPlayer = self.otherPlayer(currentPlayer)
            move = currentPlayer['player'].makeAMove(board.copy(), currentPlayer['reward'])
            (done, winner) = self.step(board, move)

        # Tell the players the final reward for the game.
        currentPlayer['player'].finalReward(currentPlayer['reward'])
        otherPlayer = self.otherPlayer(currentPlayer)
        otherPlayer['player'].finalReward(otherPlayer['reward'])

        result = 'Tie game.' if winner is None else f'{winner["mark"]} wins.'
        print('\n\n' + result)
        self.render(board)

    @staticmethod
    def marksAtIndices(board, indices):
        if type(indices) == str:
            print(indices)
        marks = [board[x] for x in indices]
        return marks

    def otherPlayer(self, aPlayer):
        player = {self.X['mark']: self.O, self.O['mark']: self.X}[aPlayer['mark']]
        return player

    def render(self, board):
        print(self.formatBoard(board))

    def step(self, board, move):
        """
        Make the move and return (done, winner). If no winner, winner will be None.
        :param board:
        :param move:
        :return: (done, winner)
        """
        currentPlayer = self.whoseTurn(board)
        otherPlayer = self.otherPlayer(currentPlayer)

        # The following are all game-ending cases.
        done = True
        if board[move] != self.emptyCell:
            # Illegal move. currentPlayer loses.
            currentPlayer['reward'] = -99
            otherPlayer['reward'] = 100
            print(f'\n\nInvalid move by {currentPlayer["mark"]}: {move}.', end='')
            return (done, otherPlayer)

        board[move] = currentPlayer['mark']
        if self.theWinner(board):
            # The current move won the game.
            currentPlayer['reward'] = 100
            otherPlayer['reward'] = -100
            return (done, currentPlayer)

        if board.count(self.emptyCell) == 0:
            # The game is over. It's a tie.
            currentPlayer['reward'] = 0
            otherPlayer['reward'] = 0
            return (done, None)

        # The game is not over.
        done = False
        currentPlayer['reward'] = -1
        return (done, None)

    def theWinner(self, board):
        """
        Is there a winner? If so return it. Otherwise, return None.
        """
        for triple in self.possibleWinners:
            [a, b, c] = self.marksAtIndices(board, triple)
            if a == b == c != self.emptyCell:
                return a
        return None

    def whoseTurn(self, board):
        player = self.O if board.count(self.X['mark']) > board.count(self.O['mark']) else self.X
        return player

class Trainer(GameManager):
    import random


    # Select the player based on the game number.
    # 'X' plays 1/6 of the games, 'O' plays 5/6
    def learnXorO(self, n):
        return 'X' if random.random() < 0.17 else 'O'

    def play_a_game(self, N, n, game_results, mov_avgs, test_frequency, delay_backprog):
        """

        :param N: Total number of games to play
        :param n: Current game number
        :param game_results:
        :param mov_avgs:
        :param: test_frequency: how often to play a test game
        :return:
        """
        learner = self.learnXorO(n)

        if n >= N-10:
            print('\nGame', n, ' =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
            print('Learner:', learner)

        # The initial observation is the initial board.
        initial_board = self.initialBoard()

        (game_reward, steps) = self.finish_game(n, learner, [(None, None, None, initial_board, False)])

        if n >= N-10 or n % test_frequency == 0:
            mov_avgs[learner] = (mov_avgs[learner] * (self.mov_avg_coeff[learner] - 1) + game_reward) / self.mov_avg_coeff[learner]
            mov_avgs[learner + '-max'] = max(int(round(mov_avgs[learner])), mov_avgs[learner + '-max'])
            print(str(n) + '. ' + self.game_outcome(learner, game_reward),
                  {'MA': str(mov_avgs[learner + '-max']) + ' - ' + str(int(round(mov_avgs[learner]))),
                   'alpha': round(self.alpha(n, learner), 2)})
            game_results[learner].append(mov_avgs[learner])
            game_results[learner + '-max'].append(mov_avgs[learner + '-max'])

        for (board, action, reward, next_board, done) in (reversed(steps) if self.delay_backprop else steps):
            self.backprop(board, action, reward, next_board, done, self.alpha(n, learner), self.gamma(learner))

    def train(self, N):
        import matplotlib.pyplot as plt

        game_results = {'X': [], 'X-max': [], 'O': [], 'O-max': []}
        mov_avgs = {'X': -100, 'X-max': -100, 'O': -100, 'O-max': -100}

        for n in range(N): self.play_a_game(n, game_results, mov_avgs)

        plt.plot(game_results['X'], 'b')
        plt.plot(game_results['X-max'], 'g')
        plt.plot(game_results['O'], 'r')
        plt.plot(game_results['O-max'], 'g')

        plt.title("Running averages - X/O (" + str(game_results['X-max'][-1]) + '-' + str(
            int(round(game_results['X'][-1]))) + '/' + str(game_results['O-max'][-1]) + '-' + str(
            int(round(game_results['O'][-1]))) + ')')

        plt.show()


class TransformableBoard:
    """
    This class represents boards that can be associated with equivalence classes of boards.
    The board is numbered as follows. The equivalence class of a board are all the boards
    it can transform into by rotations and flips.

    Boards are numbered as follows.

            0 1 2
            3 4 5
            6 7 8
    """

    def __init__(self):
        """
        The rotate pattern puts: the item originally in cell 6 into cell 0
                                 the item originally in cell 3 into cell 1
                                 the item originally in cell 0 into cell 2
                                 etc.
        In other words, it rotates the board 90 degrees clockwise.
        The flip pattern flips the board horizontally about its center column.
        See transformAux() to see these patterns in action.

        0 to 3 rotates and  0 or 1 flip generates all the equivalent boards.
        See representative() to see how all the equivalent boards are generated.
        """
        self.rotatePattern = [6, 3, 0,
                              7, 4, 1,
                              8, 5, 2]
        self.flipPattern = [2, 1, 0,
                            5, 4, 3,
                            8, 7, 6]

    @staticmethod
    def applyPattern(board, pattern):
        return [board[i] for i in pattern]

    def representative(self, board):
        """
        Generate the equivalence class of boards and select the lexicographically smallest.
        :param board:
        :return: (board, rotations, flips); rotations will be in range(4); flips will be in range(2)
                 The rotations and flips are returned so that they can be undone later.
        """
        sortedTransformation = sorted([(self.transform(board, r, f), r, f) for r in range(4) for f in range(2)])
        return sortedTransformation[0]

    def restore(self, board, r, f):
        """
        Unflip and then unrotate the board
        :param board:
        :param r:
        :param f:
        :return:
        """
        # unflipping is the same as flipping a second time.
        unflipped = self.transformAux(board, self.flipPattern, f)
        # unrotating is the same as rotating 4 - r times.
        unrotateedAndFlipped = self.transformAux(unflipped, self.rotatePattern, 4 - r)
        return unrotateedAndFlipped

    def reverseTransformMove(self, move, r, f):
        """
        Unflip and then unrotate the move position.
        :param move:
        :param r:
        :param f:
        :return:
        """
        board = list('_' * 9)
        board[move] = 'M'
        restoredBoard = self.restore(board, r, f)
        nOrig = restoredBoard.index('M')
        return nOrig

    def transform(self, board, r, f):
        """
        Perform r rotations and then f flips on the board
        :param board:
        :param r: number of rotations
        :param f: number of flips
        :return: the rotated and flipped board
        """
        rotated = self.transformAux(board, self.rotatePattern, r)
        rotatedAndFlipped = self.transformAux(rotated, self.flipPattern, f)
        return rotatedAndFlipped

    def transformAux(self, board, pattern, n):
        """
        Rotate or flip the board (according to the pattern) n times.
        :param board:
        :param pattern:
        :param n:
        :return: the transformed board
        """
        if n == 0:
            return board
        else:
            return self.transformAux(self.applyPattern(board, pattern), pattern, n - 1)


if __name__ == '__main__':
    gameManager = GameManager(MinimaxPlayer, HumanPlayer)
    gameManager.main()


