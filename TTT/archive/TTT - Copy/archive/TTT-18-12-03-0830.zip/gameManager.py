
# noinspection PyUnresolvedReferences
from players import HumanPlayer, LearningPlayer, PrettyGoodPlayer, ValidMovePlayer
from transform import formatBoard

class GameManager:

    def __init__(self):
        self.emptyCell =  '.'
        self.board = list(self.emptyCell * 9)
        self.majDiag = [0, 4, 8]
        self.minDiag = [2, 4, 6]
        self.moves = list(range(9))  #spaces.Discrete(9) # always 9 possible moves, including illegal moves
        self.X = {'mark':'X', 'reward': 0, 'player': None}
        self.O = {'mark':'O', 'reward': 0, 'player': None}


    def gameWon(self, move):
        isWon = (self.tripleMarks(self.majDiag) or
                 self.tripleMarks(self.minDiag) or
                 self.tripleMarks(self.getRowAt(move)) or
                 self.tripleMarks(self.getColAt(move)))
        return isWon

    @staticmethod
    def getRowAt(move):
        rowStart = (move//3) * 3
        row = [rowStart, rowStart+1, rowStart+2]
        return row

    @staticmethod
    def getColAt(move):
        colStart = move % 3
        col = [colStart, colStart+3, colStart+6]
        return col

    def main(self, xPlyr, oPlyr):
        self.X['player'] = xPlyr
        self.O['player'] = oPlyr
        self.mainLoop()

    def mainLoop(self):
        currentPlayer = self.O
        done = False
        winner = None
        while not done:
            currentPlayer = self.otherPlayer(currentPlayer)
            move = currentPlayer['player'].makeAMove(self.board.copy(), currentPlayer['reward'])
            (done, winner) = self.step(move)

        # Tell the players the final reward for the game.
        currentPlayer['player'].finalReward(currentPlayer['reward'])
        otherPlayer = self.otherPlayer(currentPlayer)
        otherPlayer['player'].finalReward(otherPlayer['reward'])

        result = '\n\n' + (f'{winner["mark"]} wins.' if winner is not None else "Tie game.")
        print(result)
        print(formatBoard(self.board))

    def marksAtIndices(self, indices):
        marks = [self.board[x] for x in indices]
        return marks

    def otherPlayer(self, aPlayer):
        player = {self.X['mark']: self.O, self.O['mark']: self.X}[aPlayer['mark']]
        return player

    def render(self):
        print(formatBoard(self.board))

    def step(self, move):
        currentPlayer = self.whosTurn()
        otherPlayer = self.otherPlayer(currentPlayer)

        done = True
        if self.board[move] != self.emptyCell:
            currentPlayer['reward'] = -99
            otherPlayer['reward'] = 100
            print(f'\n\nInvalid move by {currentPlayer["mark"]}: {move}.', end='')
            return (done, otherPlayer)

        self.board[move] = currentPlayer['mark']
        if self.gameWon(move):
            currentPlayer['reward'] = 100
            otherPlayer['reward'] = -100
            return (done, currentPlayer)

        if self.board.count(self.emptyCell) == 0:
            currentPlayer['reward'] = 0
            otherPlayer['reward'] = 0
            return (done, None)

        done = False
        currentPlayer['reward'] = -1
        return (done, None)

    def tripleMarks(self, tripleIndices):
        marks = [a, b, c] = self.marksAtIndices(tripleIndices)
        return not self.emptyCell in marks and a == b == c

    def whosTurn(self):
        player = (self.O if self.board.count(self.X['mark']) > self.board.count(self.O['mark']) else self.X)
        return player

if __name__ == '__main__':
    gameManager = GameManager()
    xPlayer = PrettyGoodPlayer(gameManager, 'X')
    oPlayer = HumanPlayer(gameManager, 'O')
    gameManager.main(xPlayer, oPlayer)


