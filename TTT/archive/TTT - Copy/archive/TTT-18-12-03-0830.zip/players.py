
from random import choice
from transform import formatBoard, representative, reverseTransform

class Player:
    """
    The board is numbered as follows.
    0 1 2
    3 4 5
    6 7 8
    """

    def __init__(self, gameManager, myMark):
        self.emptyCell = gameManager.emptyCell
        self.myMark = myMark
        self.opponentMark = {'X':'O', 'O':'X'}[myMark]

        # A functino that converts a list of board indices to the marks at those indices.
        # marksAtIndices(indices) = [board[i] for i in indices]
        self.marksAtIndices = gameManager.marksAtIndices

        self.corners = [0, 2, 6, 8]

        getRowAt = gameManager.getRowAt
        getColAt = gameManager.getColAt
        self.possibleWinners = [gameManager.majDiag, gameManager.minDiag,
                                getRowAt(0), getRowAt(3), getRowAt(6),
                                getColAt(0), getColAt(1), getColAt(2)]



    def finalReward(self, reward):
        """
        This is called after the game is over. It informs the player of its final reward.
        :param reward: The final reward for the game.
        :return: None
        """
        # print(f"\n{self.myMark}'s final reward: {reward}", end='')
        pass

    def isAvailable(self, board, pos):
        return board[pos] == self.emptyCell

    def makeAMove(self, board, reward):
        return choice(list(range(9)))

    def validMoves(self, board):
        validMoves = [i for i in range(9) if self.isAvailable(board, i)]
        return validMoves


class HumanPlayer(Player):

    def makeAMove(self, board, reward):
        # print(f'{self.myMark} reward: {reward}')
        print()
        print(formatBoard(board))
        c = '-1'
        while not c in "012345678" or not (0 <= int(c) <= 8):
            c = input(f'{self.myMark} to move > ')
        return int(c)


class LearningPlayer(Player):

    def finalReward(self, reward):
        """
        Update the qValues to include the game's final reward.
        :param reward:
        :return: None
        """
        pass

    def makeAMove(self, board, reward):
        (equivBoard, r, f) = representative(board)

        """
        Update qValues select a move based on representative board from this board's equivalence class.
        Your move should not be random like the following.
        """
        move = choice(self.validMoves(equivBoard))
        return reverseTransform(move, r, f)


class ValidMovePlayer(Player):

    def makeAMove(self, board, reward):
        return choice(self.validMoves(board))


class PrettyGoodPlayer(ValidMovePlayer):

    def makeAMove(self, board, reward):
        """
        If this player can win, do so.
        If not, block if the other player can win.
        Otherwise make a random but valid move.
        :param board:
        :param reward:
        :return:
        """
        # print(f'{self.myMark} reward: {reward}')
        myWins = set()
        myBlocks = set()
        emptyCell = self.emptyCell
        for possWin in self.possibleWinners:
            marks = self.marksAtIndices(possWin)
            if marks.count(emptyCell) == 1:
                if marks.count(self.myMark) == 2:
                    myWins.add(possWin[marks.index(emptyCell)])
                if marks.count(self.opponentMark) == 2:
                    myBlocks.add(possWin[marks.index(emptyCell)])
        if myWins:
            return choice(list(myWins))
        if myBlocks:
            return choice(list(myBlocks))

        corners = self.corners
        cornerMarks = self.marksAtIndices(corners)
        availableCorners = [i for (i, m) in zip(corners, cornerMarks) if m == self.emptyCell]

        move = (choice(availableCorners) if len(availableCorners) > 0 else
                4 if self.isAvailable(board, 4) else
                super().makeAMove(board, reward)
                )
        return move


