
from random import choice
from transform import formatBoard, representative, reverseTransform

class Player:
    """
    The board is numbered as follows.
    0 1 2
    3 4 5
    6 7 8
    """

    def __init__(self, gameManager):
        self.emptyCell = gameManager.emptyCell

        # A functino that converts a list of board indices to the marks at those indices.
        # marksAtIndices(indices) = [board[i] for i in indices]
        self.marksAtIndices = gameManager.marksAtIndices
        self.theWinner = gameManager.theWinner

        self.possibleMoves = gameManager.possibleMoves
        self.corners = [0, 2, 6, 8]
        self.sides = [1, 3, 5, 7]
        self.myMark = None
        self.opMark = None
        self.possibleWinners = gameManager.possibleWinners

    def finalReward(self, reward):
        """
        This is called after the game is over. It informs the player of its final reward.
        :param reward: The final reward for the game.
        :return: None
        """
        pass

    def isAvailable(self, board, pos):
        return board[pos] == self.emptyCell

    def makeAMove(self, board, reward):
        return choice(list(range(9)))

    def otherMark(self, mark):
        return {self.myMark: self.opMark, self.opMark: self.myMark}[mark]

    @staticmethod
    def oppositeCorner(pos):
        return {0: 8, 2: 6, 6: 2, 8: 0}[pos]

    def setMarks(self, gameManager):
        self.myMark = gameManager.X['mark'] if gameManager.X['player'] == self else gameManager.O['mark']
        self.opMark = gameManager.O['mark'] if gameManager.X['player'] == self else gameManager.X['mark']

    def theWinner(self, board):
        for triple in self.possibleWinners:
            marks = [a, b, c] = self.marksAtIndices(board, triple)
            winner = a if not self.emptyCell in marks and a == b == c else None
            if winner is not None:
                return winner
        return None

    def validMoves(self, board):
        validMoves = [i for i in range(9) if self.isAvailable(board, i)]
        return validMoves


class HumanPlayer(Player):

    def makeAMove(self, board, reward):
        # print(f'{self.myMark} reward: {reward}')
        print()
        print(formatBoard(board))
        c = '-1'
        while not c in "012345678" or not (0 <= int(c) <= 8):
            c = input(f'{self.myMark} to move > ')
        return int(c)


class LearningPlayer(Player):

    def finalReward(self, reward):
        """
        Update the qValues to include the game's final reward.
        :param reward:
        :return: None
        """
        pass

    def makeAMove(self, board, reward):
        (equivBoard, r, f) = representative(board)

        """
        Update qValues select a move based on representative board from this board's equivalence class.
        Your move should not be random like the following.
        """
        move = choice(self.validMoves(equivBoard))
        return reverseTransform(move, r, f)


class ValidMovePlayer(Player):

    def makeAMove(self, board, reward):
        return choice(self.validMoves(board))


class PrettyGoodPlayer(ValidMovePlayer):

    def makeAMove(self, board, reward):
        """
        If this player can win, do so.
        If not, block if the other player can win.
        Otherwise make a random but valid move.
        :param board:
        :param reward:
        :return:
        """
        # print(f'{self.myMark} reward: {reward}')
        myWins = set()
        myBlocks = set()
        emptyCell = self.emptyCell
        for possWin in self.possibleWinners:
            marks = self.marksAtIndices(board, possWin)
            if marks.count(emptyCell) == 1:
                if marks.count(self.myMark) == 2:
                    myWins.add(possWin[marks.index(emptyCell)])
                if marks.count(self.opMark) == 2:
                    myBlocks.add(possWin[marks.index(emptyCell)])
        if myWins:
            return choice(list(myWins))
        if myBlocks:
            return choice(list(myBlocks))

        # O's first move should be in the center if it's available.
        # X's second move should be center if O's first move was a side move
        emptyCells = board.count(self.emptyCell)
        if (emptyCells == 8 and self.isAvailable(board, 4) or
            emptyCells == 7 and board.index(self.opMark) % 2 == 1):
            return 4
        if emptyCells == 7 and not self.isAvailable(board, 4):
            return self.oppositeCorner(board.index(self.myMark))

        corners = self.corners
        cornerMarks = self.marksAtIndices(board, corners)
        availableCorners = [i for (i, m) in zip(corners, cornerMarks) if m == self.emptyCell]

        # O should not go in a corner on second move if X has diagonal corners
        if emptyCells == 6 and len(availableCorners) == 2:
            return choice([pos for pos in self.sides if self.isAvailable(board, pos)])

        move = (choice(availableCorners) if len(availableCorners) > 0 else
                4 if self.isAvailable(board, 4) else
                super().makeAMove(board, reward)
                )
        return move


class MinimaxPlayer(PrettyGoodPlayer):

    def makeAndEvaluateMove(self, board, move, mark):
        """
        Make the move and evaluate the board.
        :param board:
        :param move:
        :param mark:
        :return: 'X' is maximizer; 'O' is minimizer
        """
        copyBoard = board.copy()
        copyBoard[move] = mark
        winner = self.theWinner(copyBoard)
        val = ( 1 if winner == 'X' else
               -1 if winner == 'O' else
                0 if copyBoard.count(self.emptyCell) == 0 else
                None
                )
        return (val, move, copyBoard)

    def makeAMove(self, board, reward):
        if board.count(self.emptyCell) >= 7:
            return super().makeAMove(board, reward)
        (_, move) = self.minimax(board, self.myMark)
        return move

    def minimax(self, board, whoseTurn):
        """
        Does minimax search
        :param board:
        :param whoseTurn: 'X' or 'O'
        :return: (val, move) best minimax move for whoseTurn
        """
        copyBoard = board.copy()
        validMoves = self.validMoves(copyBoard)
        # Returns [(val, move, board)] val in [1, 0, -1, None}
        myPossMoves = [self.makeAndEvaluateMove(copyBoard, move, whoseTurn) for move in validMoves]
        winningVal = 1 if whoseTurn == 'X' else -1
        winners = [(val, move) for (val, move, _) in myPossMoves if val == winningVal]
        if winners:
            return choice(winners)

        # There won't be any losers. A player can't lose on its own move.
        stillOpen = [(move, board) for (val, move, board) in myPossMoves if val is None]
        # not stillOpen means that all the spaces have been taken. So game is a tie.
        if not stillOpen:
            # There should be at most one tie
            ties = [(val, move) for (val, move, _) in myPossMoves if val == 0]
            return ties[0]

        # But there may be some moves for which the game is not yet decided.
        # Run minimax on them. Keep track of the move that got there.
        minimaxResults = [(self.minimax(board, self.otherMark(whoseTurn)), move) for (move, board) in stillOpen]
        # val will not be relative to whoseMove. It will be absolute: 1 for 'X' wins and -1 for 'O' wins.
        # The _ in the following is the best move for the other side, which we don't care about.
        minOrMax = max if whoseTurn == 'X' else min
        ((val, _), move) = minOrMax(minimaxResults, key=lambda mmMove: mmMove[0][0] )
        return (val, move)
