
# noinspection PyUnresolvedReferences
from players import HumanPlayer, LearningPlayer, MinimaxPlayer, PrettyGoodPlayer, ValidMovePlayer
from transform import formatBoard

class GameManager:

    def __init__(self, xPlayerClass, oPlayerClass):
        self.emptyCell =  '.'
        self.board = list(self.emptyCell * 9)
        self.majDiag = [0, 4, 8]
        self.minDiag = [2, 4, 6]
        self.possibleMoves = list(range(9))  # 9 possible moves, including illegal moves
        getRowAt = self.getRowAt
        getColAt = self.getColAt
        self.possibleWinners = [self.majDiag, self.minDiag,
                                getRowAt(0), getRowAt(3), getRowAt(6),
                                getColAt(0), getColAt(1), getColAt(2)]

        self.X = {'mark':'X', 'reward': 0, 'player': xPlayerClass(self)}
        self.O = {'mark':'O', 'reward': 0, 'player': oPlayerClass(self)}
        self.X['player'].setMarks(self)
        self.O['player'].setMarks(self)

    @staticmethod
    def getColAt(move):
        colStart = move % 3
        col = [colStart, colStart+3, colStart+6]
        return col

    @staticmethod
    def getRowAt(move):
        rowStart = (move//3) * 3
        row = [rowStart, rowStart+1, rowStart+2]
        return row

    def main(self):
        self.mainLoop()

    def mainLoop(self):
        currentPlayer = self.O
        done = False
        winner = None
        while not done:
            currentPlayer = self.otherPlayer(currentPlayer)
            move = currentPlayer['player'].makeAMove(self.board.copy(), currentPlayer['reward'])
            (done, winner) = self.step(move)

        # Tell the players the final reward for the game.
        currentPlayer['player'].finalReward(currentPlayer['reward'])
        otherPlayer = self.otherPlayer(currentPlayer)
        otherPlayer['player'].finalReward(otherPlayer['reward'])

        result = '\n\n' + (f'{winner["mark"]} wins.' if winner is not None else "Tie game.")
        print(result)
        print(formatBoard(self.board))

    @staticmethod
    def marksAtIndices(board, indices):
        if type(indices) == str:
            print(indices)
        marks = [board[x] for x in indices]
        return marks

    def otherPlayer(self, aPlayer):
        player = {self.X['mark']: self.O, self.O['mark']: self.X}[aPlayer['mark']]
        return player

    def render(self):
        print(formatBoard(self.board))

    def step(self, move):
        currentPlayer = self.whoseTurn()
        otherPlayer = self.otherPlayer(currentPlayer)

        done = True
        if self.board[move] != self.emptyCell:
            currentPlayer['reward'] = -99
            otherPlayer['reward'] = 100
            print(f'\n\nInvalid move by {currentPlayer["mark"]}: {move}.', end='')
            return (done, otherPlayer)

        self.board[move] = currentPlayer['mark']
        if self.theWinner(self.board):
            currentPlayer['reward'] = 100
            otherPlayer['reward'] = -100
            return (done, currentPlayer)

        if self.board.count(self.emptyCell) == 0:
            currentPlayer['reward'] = 0
            otherPlayer['reward'] = 0
            return (done, None)

        done = False
        currentPlayer['reward'] = -1
        return (done, None)

    def theWinner(self, board):
        for triple in self.possibleWinners:
            marks = [a, b, c] = self.marksAtIndices(board, triple)
            winner = a if not self.emptyCell in marks and a == b == c else None
            if winner is not None:
                return winner
        return None

    def whoseTurn(self):
        player = (self.O if self.board.count(self.X['mark']) > self.board.count(self.O['mark']) else self.X)
        return player

if __name__ == '__main__':
    gameManager = GameManager(HumanPlayer, MinimaxPlayer)
    gameManager.main()


