
from itertools import zip_longest
# noinspection PyUnresolvedReferences
from players import HardWiredPlayer, HumanPlayer, LearningPlayer, MinimaxPlayer, WinsBlocksCornersPlayer
from qTable import QTable
from utils import EMPTYCELL, NEWBOARD, formatBoard, render, setMove, theWinner

class GameManager:

    def __init__(self, xPlayerClass: type, oPlayerClass: type) -> None:
        # self.majDiag = [0, 4, 8]
        # self.minDiag = [2, 4, 6]
        #
        # # Define these local names to make self.possibleWinners shorter
        # # getRowAt = self.getRowAt
        # # getColAt = self.getColAt
        # # These are the eight three-element sequences that could make a win.
        # self.possibleWinners = [self.majDiag, self.minDiag,
        #                         getRowAt(0), getRowAt(3), getRowAt(6),
        #                         getColAt(0), getColAt(1), getColAt(2)]

        # This is the qTable object instantiated from the QTable class.
        self.qTable = QTable()

        # Create the players and tell them which side they are playing.
        # The cachedReward field is the reward stored temporarily to be passed to the player on its next move.
        self.X = {'mark': 'X', 'cachedReward': 0, 'player': xPlayerClass(self, 'X')}
        self.O = {'mark': 'O', 'cachedReward': 0, 'player': oPlayerClass(self, 'O')}

    def main(self):
        (winner, finalBoard) = self.mainLoop()
        result = 'Tie game.' if winner is None else f'{winner["mark"]} ({winner["player"].getName()}) wins.'
        print('\n\n' + result)
        render(finalBoard)
        self.printReplay(finalBoard, result)
        return (self.X['player'], self.O['player'])

    def mainLoop(self) -> (str, str):
        board = NEWBOARD

        # X always makes the first move.
        (currentPlayer, done, winner) = (self.X, False, None)
        while not done:
            move = currentPlayer['player'].makeAMove(currentPlayer['cachedReward'], board)
            (done, winner, board) = self.step(board, move)
            currentPlayer = self.otherPlayer(currentPlayer)

        # Tell the players the final reward for the game.
        currentPlayer['player'].finalReward(currentPlayer['cachedReward'])
        otherPlayer = self.otherPlayer(currentPlayer)
        otherPlayer['player'].finalReward(otherPlayer['cachedReward'])
        return (winner, board)

    def otherPlayer(self, aPlayer: dict) -> dict:
        player = self.O if aPlayer is self.X else self.X
        return player

    def printReplay(self, finalBoard: str, result: str) -> None:
        xMoves = self.X['player'].sarsList
        oMoves = self.O['player'].sarsList
        print(f'\n\nReplay: {self.X["player"].getName()} (X) vs {self.O["player"].getName()} (O)')
        # xMoves will be one longer than oMoves unless O wins. Make an extra oMove (None, None, None) if necessary.
        zippedMoves = list(zip_longest(xMoves, oMoves, fillvalue=(None, None, None, None)))
        for xoMoves in zippedMoves:
            ((xBoard, xMove, _, _), (oBoard, oMove, _, _)) = xoMoves
            # Don't print the initial empty board.
            print("" if xBoard == NEWBOARD else formatBoard(xBoard) + "\n", f'\nX -> {xMove}')
            if oBoard is not None:
                print(f'{formatBoard(oBoard)}\n\nO -> {oMove}')
        print(f'{formatBoard(finalBoard)}\n{result}')

    def step(self, board: str, move: int) -> (bool, str, str):
        """
        Make the move and return (done, winner). If no winner, winner will be None.
        :param board:
        :param move:
        :return: (done, winner)
        """
        currentPlayer = self.whoseTurn(board)
        otherPlayer = self.otherPlayer(currentPlayer)

        # The following are all game-ending cases.
        done = True
        if board[move] is not EMPTYCELL:
            # Illegal move. currentPlayer loses.
            currentPlayer['cachedReward'] = -100
            otherPlayer['cachedReward'] = 100
            print(f'\n\nInvalid move by {currentPlayer["mark"]}: {move}.', end='')
            return (done, otherPlayer, board)

        # board[move] = currentPlayer['mark']
        updatedBoard = setMove(board, move, currentPlayer['mark'])
        if theWinner(updatedBoard):
            # The current move won the game.
            currentPlayer['cachedReward'] = 100
            otherPlayer['cachedReward'] = -100
            return (done, currentPlayer, updatedBoard)

        if updatedBoard.count(EMPTYCELL) == 0:
            # The game is over. It's a tie.
            currentPlayer['cachedReward'] = 0
            otherPlayer['cachedReward'] = 0
            return (done, None, updatedBoard)

        # The game is not over.
        done = False
        # Get a reward for extending the game.
        currentPlayer['cachedReward'] = 1
        return (done, None, updatedBoard)

    def whoseTurn(self, board: str) -> dict:
        player = self.O if board.count(self.X['mark']) > board.count(self.O['mark']) else self.X
        return player


if __name__ == '__main__':
    gameManager = GameManager(HumanPlayer, WinsBlocksCornersPlayer)
    gameManager.main()


