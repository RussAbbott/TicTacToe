
from gameManager import GameManager
# noinspection PyUnresolvedReferences
from itertools import zip_longest
from matplotlib import pyplot as plt
# noinspection PyUnresolvedReferences
from players import HardWiredPlayer, HumanPlayer, LearningPlayer, MinimaxPlayer, WinsBlocksCornersPlayer
# noinspection PyUnresolvedReferences
import random
# noinspection PyUnresolvedReferences
# from qTable import EMPTYCELL
from typing import Optional
from utils import alpha, gamma


class Trainer(GameManager):

    def __init__(self, xPlayerClass: type, oPlayerClass: type, N:int=1000, test_frequency:float=0.10) -> None:
        self.game_results = {'X': [], 'X-max': [], 'O': [], 'O-max': []}
        self.mov_avgs = {'X': -100, 'X-max': -100, 'O': -100, 'O-max': -100}

        # Total number of games to play
        self.N = N
        # Which of the N games are we playing
        self.n = 0
        # The frequence of test games, expressed as a percentage of N
        self.test_frequency = test_frequency
        self.cycleLength = round(self.N * self.test_frequency)
        super().__init__(xPlayerClass, oPlayerClass)

    def is_test_game(self) -> bool:
        return self.n % self.cycleLength == 0

    def play_a_game(self) -> None:
        (xPlayer, oPlayer) = self.main()
        if isinstance(xPlayer, LearningPlayer):
            self.updateFromSarsList(xPlayer.myMark, xPlayer.sarsList)
        if isinstance(oPlayer, LearningPlayer):
            self.updateFromSarsList(oPlayer.myMark, oPlayer.sarsList)
        self.qTable.printQTable(self.whoseTurn)
        # for (mark, player) in [('X', self.X['player']), ('O', self.O['player'])]:
        #     if type(player) is LearningPlayer:
        #         moves = reversed(player.sarList)
        #         for (board, move, reward, nextBoard) in player.sarsList:
        #             self.update(board, move, reward, nextBoard, nextBoard is None,
        #                         self.alpha(self.n, mark), self.gamma(mark))
        #
    #     learner = None
    #
    #     if self.n >= self.N-10:
    #         print('\nGame', self.n, ' =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
    #         print('Learner:', learner)
    #
    #     # The initial observation is the initial board.
    #     initial_board = self.initialBoard()
    #     (game_reward, steps) = self.finish_game(self.n, learner, [(None, None, None, initial_board, False)])
    #
    #     if self.n >= self.N-10 or self.is_test_game():
    #         self.mov_avgs[learner] = (self.mov_avgs[learner] * (self.mov_avg_coeff[learner] - 1) + game_reward) / self.mov_avg_coeff[learner]
    #         self.mov_avgs[learner + '-max'] = max(int(round(self.mov_avgs[learner])), self.mov_avgs[learner + '-max'])
    #         print(str(self.n) + '. ' + self.game_outcome(learner, game_reward),
    #               {'MA': str(self.mov_avgs[learner + '-max']) + ' - ' + str(int(round(self.mov_avgs[learner]))),
    #                'alpha': round(self.alpha(learner, self.n), 2)})
    #         self.game_results[learner].append(self.mov_avgs[learner])
    #         self.game_results[learner + '-max'].append(self.mov_avgs[learner + '-max'])
    #
    #     for (board, action, reward, next_board, done) in (reversed(steps)):
    #         self.update(board, action, reward, next_board, done, self.alpha(learner, self.n), self.gamma(learner))

    def train(self) -> None:
        for self.n in range(self.N):
            self.play_a_game()

        plt.plot(self.game_results['X'], 'b')
        plt.plot(self.game_results['X-max'], 'g')
        plt.plot(self.game_results['O'], 'r')
        plt.plot(self.game_results['O-max'], 'g')

        plt.title("Running averages - X/O (" + str(self.game_results['X-max'][-1]) + '-' + str(
            int(round(self.game_results['X'][-1]))) + '/' + str(self.game_results['O-max'][-1]) + '-' + str(
            int(round(self.game_results['O'][-1]))) + ')')

        plt.show()

        #        Compute new value for Q[state][action]
        #        Qs = Q[s]
        #        Qnext is the state to which Qs goes after taking action a
        #        max_Qnext is the current estimate of the best possible result from Qnext
        #        Qsav is the current value of Q[s][a]
        #        Qsav' will be the updated value of Q[s][a]

        #        Transform the traditional formula to the alpha-weighted formula.
        #        Qsav' += alpha * (reward + gamma * max_Qnext - Qsav)  -- Traditional formula
        #        Qsav' =  Qsav + alpha * (reward + gamma * max_Qnext - Qsav)
        #        Qsav' =  Qsav + alpha * (reward + gamma * max_Qnext) - alpha * Qsav
        #        Formula in terms of weights.
        #        Qsav' =  (1 - alpha) * Qsav  +  alpha * (reward + gamma * max_Qnext)
    def update(self, mark: str, board: str, move: int, reward: float, nextBoard: Optional[str]) -> None:
        # When done, there is no next state.
        done = nextBoard is None
        nextStateBestQValue = 0 if done else self.qTable.getBestQValue(nextBoard)
        newQValue = reward + gamma(mark) * nextStateBestQValue
        self.qTable.updateQValue(board, move, alpha(self.n/self.N, mark), newQValue)
        # board[move] = 'M'
        # repBoard = self.representative(board)
        # repMove = repBoard.index('M')
        # board[move] = EMPTYCELL
        # q_values = self.qTable.getQstate(board)
        # q_values[repMove] = (1 - alpha) * q_values[repMove] + alpha * (reward + gamma * max_next_state_forecast)

    def updateFromSarsList(self, mark: str, sarsList: [(str, int, float, str)]) -> None:
        # for (mark, player) in [('X', self.X['player']), ('O', self.O['player'])]:
        #     if type(player) is LearningPlayer:
        # moves = reversed(sarsList)
        for (board, move, reward, nextBoard) in reversed(sarsList):
            self.update(mark, board, move, reward, nextBoard)

if __name__ == '__main__':
    trainer = Trainer(LearningPlayer, HumanPlayer)
    trainer.play_a_game()


