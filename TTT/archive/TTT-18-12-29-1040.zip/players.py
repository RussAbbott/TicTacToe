
from qTable import qTable
from random import choice
from typing import AnyStr, List, NoReturn, Set, Tuple
from utils import CENTER, CORNERS, EMPTYCELL, SIDES, XMARK, OMARK, formatBoard, isAvailable, marksAtIndices, \
                    possibleWinners, oppositeCorner, otherMark, setMove, theWinner, validMoves, whichMarkToMove


SarsList = List[Tuple[AnyStr, int, float, AnyStr]]


# noinspection PyUnusedLocal
class Player:
    """
    The board is numbered as follows.
    0 1 2
    3 4 5
    6 7 8
    """

    def __init__(self, myMark: AnyStr) -> NoReturn:
        # self.isATestGame = None
        self.myMark = myMark
        self.opMark = otherMark(myMark)
        self.prevBoardMove = None
        self.sarsList: SarsList = []

        self.typeName = type(self).__name__

    def finalReward(self, reward: float) -> SarsList:
        """
        This is called after the game is over to inform the player of its final reward.
        :param reward: The final reward for the game.
        # :param finalBoard: The final board of the game.
        :return: None
        """
        (board, move) = self.prevBoardMove
        self.sarsList.append((board, move, reward, None))
        return self.sarsList

    def makeAMove(self, reward: float, board: AnyStr, isATestGame: bool=True) -> int:
        """
        Called by the GameManager to get this player's move.
        :param reward:
        :param board:
        :param isATestGame:
        :return: A move
        """
        move = self._makeAMove(board, isATestGame)
        self.updateSarsList(reward, board, move)
        return move

    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        move = choice(validMoves(board))
        return move

    def reset(self) -> NoReturn:
        self.prevBoardMove = None
        self.sarsList = []

    def updateSarsList(self, reward: float, curBoard: AnyStr, curMove: int) -> NoReturn:
        if self.prevBoardMove is not None:
            (board, move) = self.prevBoardMove
            self.sarsList.append((board, move, reward, curBoard))
        self.prevBoardMove = (curBoard, curMove)


class HumanPlayer(Player):

    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        print(f'\n{formatBoard(board)}')
        c = '-1'
        while c not in "012345678" or len(c) != 1 or not isAvailable(board, int(c)):
            c = input(f'{self.myMark} to move > ')
        move = int(c)
        return move


class LearningPlayer(Player):

    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        """
        Update qValues and select a move based on representative board from this board's equivalence class.
        Should not be random like the following.
        """
        # Either a random move or the move with the highest QValue for this state.
        move = (qTable.getBestMove(board, self.typeName) if isATestGame else
                choice(validMoves(board))
                )
        return move


class WinsBlocksForksCornersPlayer(Player):

    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        (myWins, otherWins, myForks, otherForks) = self.winsBlocksForks(board)
        availCornersAndCenter = [pos for pos in CORNERS + [CENTER] if isAvailable(board, pos)]
        move = choice([self.findAnEMPTYCELL(board, my_2) for my_2 in myWins] if myWins else
                      [self.findAnEMPTYCELL(board, other_2) for other_2 in otherWins] if otherWins else
                      myForks if myForks else
                      otherForks if otherForks else
                      availCornersAndCenter if availCornersAndCenter else
                      validMoves(board)
                      )
        return move

    @staticmethod
    def findAnEMPTYCELL(board: AnyStr, threeInRow: Tuple[int, int, int]) -> int:
        """
        Return a choice of the EMPTYCELL positions in threeInRow. (There is guaranteed to be one.)
        :param board:
        :param threeInRow:
        :return:
        """
        emptyCells = [index for index in threeInRow if isAvailable(board, index)]
        return choice(emptyCells)

    @staticmethod
    def findForks(board: AnyStr, singletons: List[Tuple[int, int, int]]) -> List[int]:
        """
        Finds moves that create forks
        :param board:
        :param singletons: A list of triples containing one non-empty cell for a given player.
        :return:
        """
        countSingletons = len(singletons)
        forkCells = {pos for idx1 in range(countSingletons-1) for idx2 in range(idx1+1, countSingletons)
                     for pos in singletons[idx1] if isAvailable(board, pos) and pos in singletons[idx2]}
        return list(forkCells)

    def winsBlocksForks(self, board: AnyStr) -> Tuple[List[Tuple[int, int, int]],
                                                      List[Tuple[int, int, int]],
                                                      List[int],
                                                      List[int]
                                                     ]:
        myWins = []
        mySingletons = []
        otherWins = []
        otherSingletons = []
        empties = []
        myForks = []
        otherForks = []
        for threeInRow in possibleWinners:
            marks = marksAtIndices(board, threeInRow)
            emptyCellCount = marks.count(EMPTYCELL)
            if emptyCellCount == 3:
                empties.append(threeInRow)
            if emptyCellCount == 1:
                if marks.count(self.myMark) == 2:
                    myWins.append(threeInRow)
                if marks.count(self.opMark) == 2:
                    otherWins.append(threeInRow)
            if emptyCellCount == 2:
                if marks.count(self.myMark) == 1:
                    mySingletons.append(threeInRow)
                if marks.count(self.opMark) == 1:
                    otherSingletons.append(threeInRow)
        if not myWins and not otherWins:
            if mySingletons:
                myForks = self.findForks(board, mySingletons)
            if otherSingletons:
               otherForks = self.findForks(board, otherSingletons)
        return (myWins, otherWins, myForks, otherForks)


class WinsBlocksPlayer(WinsBlocksForksCornersPlayer):

    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        (myWins, otherWins, _, _) = self.winsBlocksForks(board)
        move = choice([self.findAnEMPTYCELL(board, my_2) for my_2 in myWins] if myWins else
                      [self.findAnEMPTYCELL(board, other_2) for other_2 in otherWins] if otherWins else
                      validMoves(board)
                      )
        return move

class HardWiredPlayer(WinsBlocksForksCornersPlayer):
    """
    Plays as well as possible. Uses a hard-wired strategy.
    """
    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        """
        If this player can win, it will.
        If not, it blocks if the other player can win.
        Otherwise it makes a random valid move.
        :param board:
        :return: selected move
        """

        (myWins, otherWins, _, _) = self.winsBlocksForks(board)
        move = choice([self.findAnEMPTYCELL(board, my_2) for my_2 in myWins] if myWins else
                      [self.findAnEMPTYCELL(board, other_2) for other_2 in otherWins] if otherWins else
                      list(self.otherMove(board, board.count(EMPTYCELL)))
                      )
        return move

    @staticmethod
    def otherMove(board: AnyStr, emptyCellsCount: int) -> Set[int]:
        """
        Special case moves.
        :param board:
        :param emptyCellsCount:
        :return: Selected move
        """

        availableCorners = {pos for pos in CORNERS if isAvailable(board, pos)}
        if emptyCellsCount == 9:
            return availableCorners
        if emptyCellsCount == 8:
            return {CENTER} if isAvailable(board, CENTER) else availableCorners
        # The following is for X's second move. It applies only if X's first move was to a corner.
        if emptyCellsCount == 7 and board.index(XMARK) in CORNERS:
            oFirstMove = board.index(OMARK)
            # If O's first move is a side cell, X should take the center.
            # Otherwise, X should take the corner opposite its first move.
            if oFirstMove in SIDES:
                return {CENTER}
            if oFirstMove == CENTER:
                opCorner = oppositeCorner(board.index(XMARK))
                return {opCorner}
            return availableCorners
        # If this is O's second move and X has diagonal corners, O should take a side move.
        # If X has two adjacent corners, O blocked (above). So, if there are 2 available corners
        # they are diagonal.
        if emptyCellsCount == 6 and len(availableCorners) == 2:
            return {pos for pos in SIDES if isAvailable(board, pos)}
        # If none of the special cases apply, take the center if available,
        # otherwise a corner, otherwise any valid move.
        return ({CENTER} if isAvailable(board, CENTER) else
                availableCorners if availableCorners else
                validMoves(board)
                )


class MinimaxPlayer(HardWiredPlayer):

    def _makeAMove(self, board: AnyStr, isATestGame: bool=True) -> int:
        # The first few moves are hard-wired into HardWiredPlayer.
        move = (super()._makeAMove(board) if board.count(EMPTYCELL) >= 7 else
                # minimax returns (val, move, count). Extract move.
                self.minimax(board)[1])
        return move

    def makeAndEvaluateMove(self, board: AnyStr, move: int, mark: AnyStr, count: int) -> Tuple[int, int, int]:
        """
        Make the move and evaluate the board.
        :param board:
        :param move:
        :param mark:
        :param count: A longer game is better.
        :return: 'X' is maximizer; 'O' is minimizer
        """
        boardCopy = setMove(board, move, mark)
        winner = theWinner(boardCopy)
        (val, count1) = ( ( 1, count) if winner == XMARK else
                          (-1, count) if winner == OMARK else
                          # winner == None. Is the game a tie because board is full?
                          ( 0, count) if boardCopy.count(EMPTYCELL) == 0 else
                          # The game is not over.  Minimax is is called as the argument to this lambda function.
                          # Minimax returns (val, move, count). Select and return val and count.
                          # move is the next player's best move.
                          (lambda mmResult: (mmResult[0], mmResult[2])) (self.minimax(boardCopy, count) )
                       )
        return (val, move, count1)

    def minimax(self, board: AnyStr, count: int=0) -> (int, int, int):
        """
        Does a minimax search.
        :param board:
        :param count: The length of the game. A longer count is better.
        :return: (val, move, count): the best minimax val for current player with longest count.
                 The move to achieve that.
        """
        mark = whichMarkToMove(board)
        # possMoves are [(val, move, count)] (val in [1, 0, -1]) for move in self.validMoves(board)]
        # These are the possible moves considering a full minimax analysis.
        possMoves = [self.makeAndEvaluateMove(board, move, mark, count+1) for move in validMoves(board)]
        minOrMax = max if mark == XMARK else min
        (bestVal, _, _) = minOrMax(possMoves, key=lambda possMove: possMove[0])
        bestMoves = [(val, move, count) for (val, move, count) in possMoves if val == bestVal]
        (_, _, longestBestMoveCount) = max(bestMoves, key=lambda possMove: possMove[2])
        # Get all moves with best val and with longest count
        longestBestMoves = [(val, move, count) for (val, move, count) in bestMoves if count == longestBestMoveCount]
        return choice(longestBestMoves)

