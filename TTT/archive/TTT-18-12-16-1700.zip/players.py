
from collections import namedtuple
from random import choice

class Player:
    """
    The board is numbered as follows.
    0 1 2
    3 4 5
    6 7 8
    """

    def __init__(self, gameManager, myMark):
        self.emptyCell = gameManager.emptyCell
        self.possibleMoves = list(range(9))  # 9 possible moves
        self.possibleWinners = gameManager.possibleWinners
        self.corners = [0, 2, 6, 8]
        self.sides = [1, 3, 5, 7]

        self.myMark = myMark
        self.opMark = self.otherMark(myMark)

        self.sarList = []
        self.PrevBoardMove = namedtuple('PrevBoardMove', ['board', 'move'])
        self.prevBoardMove = None

        # References to GameManager functions.
        self.formatBoard = gameManager.formatBoard
        # o marksAtIndices converts a list of board indices to the marks at those indices.
        #   marksAtIndices(indices) = [board[i] for i in indices]
        self.marksAtIndices = gameManager.marksAtIndices
        # o theWinner determines if there is a winner.
        self.theWinner = gameManager.theWinner
        self.whoseTurn = gameManager.whoseTurn

        self.transformer = gameManager.transformer
        
    def finalReward(self, reward):
        """
        This is called after the game is over to inform the player of its final reward.
        This function should use that information in learning.
        :param reward: The final reward for the game.
        # :param finalBoard: The final board of the game.
        :return: None
        """
        # self.updateSarList(reward, None, None)
        (board, move) = self.prevBoardMove
        self.sarList.append((board, move, reward))
        # self.sarList.append((finalBoard, None, None))
        return self.sarList

    def getName(self):
        return type(self).__name__

    def isAvailable(self, board, pos):
        return board[pos] == self.emptyCell

    def makeAMove(self, reward, board):
        """
        Called by the GameManager to get this player's move.
        :param board:
        :param reward:
        :return: A move
        """
        move = choice(list(range(9)))
        self.updateSarList(reward, board, move)
        return move

    @staticmethod
    def oppositeCorner(pos):
        return {0: 8, 2: 6, 6: 2, 8: 0}[pos]

    @staticmethod
    def otherMark(mark):
        return {'X': 'O', 'O': 'X'}[mark]

    def theWinner(self, board):
        for triple in self.possibleWinners:
            [a, b, c] = self.marksAtIndices(board, triple)
            if self.emptyCell != a == b == c:
                return a
        return None

    def updateSarList(self, reward, curBoard, curMove):
        if self.prevBoardMove is not None:
            (board, move) = self.prevBoardMove
            self.sarList.append((board, move, reward))
        self.prevBoardMove = self.PrevBoardMove(board=curBoard, move=curMove)

    def validMoves(self, board):
        valids = [i for i in range(9) if self.isAvailable(board, i)]
        return valids


class HumanPlayer(Player):

    def makeAMove(self, reward, board):
        print(f'\n{self.formatBoard(board)}')
        c = '-1'
        while c not in "012345678" or len(c) != 1 or not self.isAvailable(board, int(c)):
            c = input(f'{self.myMark} to move > ')
        move = int(c)
        self.updateSarList(reward, board, move)
        return move


class LearningPlayer(Player):

    def makeAMove(self, reward, board):
        (equivBoard, r, f) = self.transformer.representative(board)
        """
        Update qValues and select a move based on representative board from this board's equivalence class.
        Should not be random like the following.
        """
        move = choice(self.validMoves(equivBoard))
        return self.transformer.reverseTransformMove(move, r, f)


class ValidMovePlayer(Player):

    def makeAMove(self, reward, board):
        move = choice(self.validMoves(board))
        self.updateSarList(reward, board, move)
        return move


class WinsAndBlocksPlayer(ValidMovePlayer):

    def makeAMove(self, reward, board):
        (myBlocks, myWins) = self.winsAndBlocks(board)
        move = choice(myWins if myWins else
                      myBlocks if myBlocks else
                      self.validMoves(board)
                     )
        self.updateSarList(reward, board, move)
        return move


    def winsAndBlocks(self, board):
        myWins = set()
        myBlocks = set()
        emptyCell = self.emptyCell
        for possWin in self.possibleWinners:
            marks = self.marksAtIndices(board, possWin)
            if marks.count(emptyCell) == 1:
                if marks.count(self.myMark) == 2:
                    myWins.add(possWin[marks.index(emptyCell)])
                if marks.count(self.opMark) == 2:
                    myBlocks.add(possWin[marks.index(emptyCell)])
        return (list(myBlocks), list(myWins))


class PrettyGoodPlayer(WinsAndBlocksPlayer):

    def makeAMove(self, reward, board):
        """
        If this player can win, it will.
        If not, it blocks if the other player can win.
        Otherwise it makes a random valid move.
        :param board:
        :param reward:
        :return: selected move
        """

        (myBlocks, myWins) = self.winsAndBlocks(board)
        move = choice(myWins if myWins else
                      myBlocks if myBlocks else
                      [self.otherMove(board)]
                      )
        self.updateSarList(reward, board, move)
        return move

    def otherMove(self, board):
        """
        Special case moves.
        :param board:
        :return: Selected move
        """
        emptyCellsCount = board.count(self.emptyCell)
        # X's first move should be in a corner.
        if emptyCellsCount == 9:
            return choice(self.corners)
        # O's first move should be in the center if it's available.
        # Otherwise, take a corner.
        if emptyCellsCount == 8:
            return 4 if self.isAvailable(board, 4) else choice(self.corners)
        # The following is for X's second move. It applies only if X's first move was to a corner.
        if emptyCellsCount == 7 and board.index('X') in self.corners:
            oFirstMove = board.index('O')
            # If O's first move is a side cell, X should take the center.
            # Otherwise, X should take the corner opposite its first move.
            if oFirstMove in self.sides:
                return 4
            if oFirstMove == 4:
                oppositeCorner = self.oppositeCorner(board.index('X'))
                return oppositeCorner
        # If this is O's second move and X has diagonal corners, O should take a side move.
        availableCorners = [i for i in self.corners if self.isAvailable(board, i)]
        # If X has two adjacent corners O was forced to block (above). So, if there are 2 available corners
        # they are diagonal.
        if emptyCellsCount == 6 and len(availableCorners) == 2:
            return choice([pos for pos in self.sides if self.isAvailable(board, pos)])
        # If none of the special cases apply, take a corner if available, otherwise the center, otherwise any valid move.
        return (choice(availableCorners) if len(availableCorners) > 0 else
                4 if self.isAvailable(board, 4) else
                self.validMoves(board)
                )


class MinimaxPlayer(PrettyGoodPlayer):

    def makeAMove(self, reward, origBoard):
        (board, r, f) = self.transformer.representative(origBoard)

        # The first few moves are hard-wired into PrettyGoodPlayer.
        move = (super().makeAMove(reward, board) if board.count(self.emptyCell) >= 7
        # minimax returns (val, move, count). Extract move
                                                 else self.minimax(board)[1])
        return self.transformer.reverseTransformMove(move, r, f)

    def makeAndEvaluateMove(self, board, move, mark, count):
        """
        Make the move and evaluate the board.
        :param board:
        :param move:
        :param mark:
        :return: 'X' is maximizer; 'O' is minimizer
        """
        boardCopy = board.copy()
        boardCopy[move] = mark
        winner = self.theWinner(boardCopy)
        (val, count1) = ( ( 1, count) if winner == 'X' else
                         (-1, count) if winner == 'O' else
                         # winner == None. Is the game a tie because board is full?
                         ( 0, count) if boardCopy.count(self.emptyCell) == 0 else
                         # The game is not over.
                         (lambda mmResult=self.minimax(boardCopy, count):
                                                      (mmResult[0], mmResult[2])) ( )
                       )
        return (val, move, count1)

    def minimax(self, board, count=0):
        """
        Does a minimax search.
        :param board:
        :return: best minimax (val, move, count) with longest count for current player.
        """
        mark = self.whoseTurn(board)['mark']
        # possMoves are [(val, move, count)] (val in [1, 0, -1]) for move in self.validMoves(board)]
        possMoves = [self.makeAndEvaluateMove(board, move, mark, count+1) for move in self.validMoves(board)]
        minOrMax = max if mark == 'X' else min
        (bestVal, _, _) = minOrMax(possMoves, key=lambda possMove: possMove[0])
        bestMoves = [(val, move, count) for (val, move, count) in possMoves if val == bestVal]
        (_, _, longestBestMoveCount) = max(bestMoves, key=lambda possMove: possMove[2])
        # Get all moves with best val and with longest count
        longestBestMoves = [(val, move, count) for (val, move, count) in bestMoves if count == longestBestMoveCount]
        return choice(longestBestMoves)

# if __name__ == '__main__':
#     # Test the board transformer.
#     from gameManager import GameManager
#     formatBoard = GameManager(Player, Player).formatBoard
#     def printFB(bd):
#         print(formatBoard(bd))
#     tb = TransformableBoard()
#
#     b = list(range(9))
#     printFB(b)
#
#     b10 = tb.transform(b, 1, 0)
#     printFB(b10)
#     printFB(tb.restore(b10, 1, 0))
#
#     b21 = tb.transform(b, 2, 1)
#     printFB(b21)
#     printFB(tb.restore(b21, 2, 1))