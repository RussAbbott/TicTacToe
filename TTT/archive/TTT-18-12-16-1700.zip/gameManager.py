
# noinspection PyUnresolvedReferences
from itertools import zip_longest
# noinspection PyUnresolvedReferences
import random
# noinspection PyUnresolvedReferences
from players import HumanPlayer, LearningPlayer, MinimaxPlayer, PrettyGoodPlayer, ValidMovePlayer, WinsAndBlocksPlayer

class GameManager:

    def __init__(self, xPlayerClass, oPlayerClass):
        self.emptyCell =  '.'
        self.majDiag = [0, 4, 8]
        self.minDiag = [2, 4, 6]

        getRowAt = self.getRowAt
        getColAt = self.getColAt
        # These are the eight three-element sequences that could make a win.
        self.possibleWinners = [self.majDiag, self.minDiag,
                                getRowAt(0), getRowAt(3), getRowAt(6),
                                getColAt(0), getColAt(1), getColAt(2)]

        self.transformer = TransformableBoard()

        # Create the players and tell them which side they are playing.
        # The cachedReward field is the reward stored temporarily to be passed to the player on its next move.
        self.X = {'mark': 'X', 'cachedReward': 0, 'player': xPlayerClass(self, 'X')}
        self.O = {'mark': 'O', 'cachedReward': 0, 'player': oPlayerClass(self, 'O')}

    @staticmethod
    def formatBoard(board):
        boardString = '\n'.join([' | '.join(board[0:3]), "--+---+---",  ' | '.join(board[3:6]), "--+---+--", ' | '.join(board[6:9])])
        return boardString

    @staticmethod
    def getColAt(move):
        """
        Return a list of the indices for the column that includes move.
        :param move:
        :return:
        """
        colStart = move % 3
        col = [colStart, colStart+3, colStart+6]
        return col

    @staticmethod
    def getRowAt(move):
        """
        Return a list of the indices for the row that includes move.
        :param move:
        :return:
        """
        rowStart = (move//3) * 3
        row = [rowStart, rowStart+1, rowStart+2]
        return row

    def initialBoard(self):
        return list(self.emptyCell * 9)

    def main(self):
        (winner, finalBoard) = self.mainLoop()
        result = 'Tie game.' if winner is None else f'{winner["mark"]} ({winner["player"].getName()}) wins.'
        print('\n\n' + result)
        self.render(finalBoard)
        self.printReplay(finalBoard, result)

    def mainLoop(self):
        board = self.newBoard()

        # X always makes the first move.
        (currentPlayer, done, winner) = (self.X, False, None)
        while not done:
            move = currentPlayer['player'].makeAMove(currentPlayer['cachedReward'], board.copy())
            (done, winner) = self.step(board, move)
            currentPlayer = self.otherPlayer(currentPlayer)

        # Tell the players the final reward for the game.
        currentPlayer['player'].finalReward(currentPlayer['cachedReward'])
        otherPlayer = self.otherPlayer(currentPlayer)
        otherPlayer['player'].finalReward(otherPlayer['cachedReward'])
        return (winner, board)

    @staticmethod
    def marksAtIndices(board, indices):
        if type(indices) == str:
            print(indices)
        marks = [board[x] for x in indices]
        return marks

    def newBoard(self):
        return list(self.emptyCell * 9)

    def otherPlayer(self, aPlayer):
        player = self.O if aPlayer is self.X else self.X
        return player

    def printReplay(self, finalBoard, result):
        xMoves = self.X['player'].sarList
        oMoves = self.O['player'].sarList
        print(f'\n\nReplay: {self.X["player"].getName()} (X) vs {self.O["player"].getName()} (O)')
        # xMoves will be one longer than oMoves unless O wins. Make extra oMove (None, None, None) if necessary.
        for ((xBoard, xMove, _), (oBoard, oMove, _)) in zip_longest(xMoves, oMoves, fillvalue=(None, None, None)):
            # Don't print the initial empty board.
            print("" if xBoard == self.newBoard() else self.formatBoard(xBoard) + "\n", f'\nX -> {xMove}')
            if oBoard is not None:
                print(f'{self.formatBoard(oBoard)}\n\nO -> {oMove}')
        print(f'{self.formatBoard(finalBoard)}\n\n{result}')

    def render(self, board):
        print(self.formatBoard(board))

    def step(self, board, move):
        """
        Make the move and return (done, winner). If no winner, winner will be None.
        :param board:
        :param move:
        :return: (done, winner)
        """
        currentPlayer = self.whoseTurn(board)
        otherPlayer = self.otherPlayer(currentPlayer)

        # The following are all game-ending cases.
        done = True
        if board[move] is not self.emptyCell:
            # Illegal move. currentPlayer loses.
            currentPlayer['cachedReward'] = -99
            otherPlayer['cachedReward'] = 100
            print(f'\n\nInvalid move by {currentPlayer["mark"]}: {move}.', end='')
            return (done, otherPlayer)

        board[move] = currentPlayer['mark']
        if self.theWinner(board):
            # The current move won the game.
            currentPlayer['cachedReward'] = 100
            otherPlayer['cachedReward'] = -100
            return (done, currentPlayer)

        if board.count(self.emptyCell) == 0:
            # The game is over. It's a tie.
            currentPlayer['cachedReward'] = 0
            otherPlayer['cachedReward'] = 0
            return (done, None)

        # The game is not over.
        done = False
        # Get a reward for extending the game.
        currentPlayer['cachedReward'] = 1
        return (done, None)

    def theWinner(self, board):
        """
        Is there a winner? If so return it. Otherwise, return None.
        """
        for triple in self.possibleWinners:
            [a, b, c] = self.marksAtIndices(board, triple)
            if a == b == c != self.emptyCell:
                return a
        return None

    def whoseTurn(self, board):
        player = self.O if board.count(self.X['mark']) > board.count(self.O['mark']) else self.X
        return player

class Trainer( ):

    def __init__(self, N, test_frequency=0.10, delay_update=True):
        self.game_results = {'X': [], 'X-max': [], 'O': [], 'O-max': []}
        self.mov_avgs = {'X': -100, 'X-max': -100, 'O': -100, 'O-max': -100}

        # Total number of games to play
        self.N = N
        # The frequence of test games, expressed as a percentage of N
        self.test_frequency = test_frequency
        # Delay update until end of game
        self.delay_update = delay_update

        # The Q states. They are added as encountered.
        self.Q = {}
        # The initial value of each Q[state]: {0:0, 1:0, ... , 8:0}
        # Don't access this directly. For each new state, make a copy with get_i_state
        self._i_state = {0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0}

    # Alpha is the learning rate. It declines with more games.
    # Select the function for alpha, which is based on player, and return alpha for a given n (game number)
    # noinspection PyShadowingNames
    def alpha(self, n, playerMark):
        alpha_fn = {'X': lambda n: min(0.5, pow(0.99, 250 * n / self.N)),
                    'O': lambda n: min(0.75, pow(0.99, 200 * n / self.N))}[playerMark]
        return alpha_fn(n)

    # Gamma is the discount rate for future results.
    @staticmethod
    def gamma(learner):
        return {'X': 0.9, 'O': 0.95}[learner]

    def get_i_state(self):
        return self._i_state.copy()

    def get_Qstate(self, board):
        return self.Q.setdefault(tuple(board), self.get_i_state())

    def is_test_game(self, n):
        frequency = self.N * self.test_frequency
        return n % frequency == 0

    # Select the learner.
    # 'X' plays 1/6 of the games, 'O' plays 5/6
    @staticmethod
    def learnXorO(xPct):
        return 'X' if random.random() <= xPct else 'O'

    def play_a_game(self, n):
        """
        :param n: Current game number
        :return:
        """
        learner = self.learnXorO(0.167)

        if n >= self.N-10:
            print('\nGame', n, ' =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=')
            print('Learner:', learner)

        # The initial observation is the initial board.
        initial_board = self.initialBoard()
        (game_reward, steps) = self.finish_game(n, learner, [(None, None, None, initial_board, False)])

        if n >= self.N-10 or self.is_test_game(n):
            self.mov_avgs[learner] = (self.mov_avgs[learner] * (self.mov_avg_coeff[learner] - 1) + game_reward) / self.mov_avg_coeff[learner]
            self.mov_avgs[learner + '-max'] = max(int(round(self.mov_avgs[learner])), self.mov_avgs[learner + '-max'])
            print(str(n) + '. ' + self.game_outcome(learner, game_reward),
                  {'MA': str(self.mov_avgs[learner + '-max']) + ' - ' + str(int(round(self.mov_avgs[learner]))),
                   'alpha': round(self.alpha(n, learner), 2)})
            self.game_results[learner].append(self.mov_avgs[learner])
            self.game_results[learner + '-max'].append(self.mov_avgs[learner + '-max'])

        for (board, action, reward, next_board, done) in (reversed(steps) if self.delay_update else steps):
            self.update(board, action, reward, next_board, done, self.alpha(n, learner), self.gamma(learner))

    def train(self, N):
        """

        :param N: The total number of games to play.
        """
        import matplotlib.pyplot as plt


        for n in range(N): self.play_a_game(n)

        plt.plot(self.game_results['X'], 'b')
        plt.plot(self.game_results['X-max'], 'g')
        plt.plot(self.game_results['O'], 'r')
        plt.plot(self.game_results['O-max'], 'g')

        plt.title("Running averages - X/O (" + str(self.game_results['X-max'][-1]) + '-' + str(
            int(round(self.game_results['X'][-1]))) + '/' + str(self.game_results['O-max'][-1]) + '-' + str(
            int(round(self.game_results['O'][-1]))) + ')')

        plt.show()

        #        Compute new value for Q[state][action]
        #        Qs = Q[s]
        #        Qnext is the state to which Qs goes after taking action a
        #        max_Qnext is the current estimate of the best possible result from Qnext
        #        Qsav is the current value of Q[s][a]
        #        Qsav' will be the updated value of Q[s][a]

        #        Transform the traditional formula to the alpha-weighted formula.
        #        Qsav' += alpha * (reward + gamma * max_Qnext - Qsav)  -- Traditional formula
        #        Qsav' =  Qsav + alpha * (reward + gamma * max_Qnext - Qsav)
        #        Qsav' =  Qsav + alpha * (reward + gamma * max_Qnext) - alpha * Qsav
        #        Formula in terms of weights.
        #        Qsav' =  (1 - alpha) * Qsav  +  alpha * (reward + gamma * max_Qnext)
    def update(self, board, action, reward, next_board, done, alpha, gamma):

        # If done, there is no next state.
        max_next_state_forecast = 0 if done else max(self.get_Qstate(next_board).values())
        q_values = self.get_Qstate(board)
        q_values[action] = (1 - alpha) * q_values[action] + alpha * (reward + gamma * max_next_state_forecast)


class TransformableBoard:
    """
    This class represents boards that can be associated with equivalence classes of boards.
    The board is numbered as follows. The equivalence class of a board are all the boards
    it can transform into by rotations and flips.

    Boards are numbered as follows.

            0 1 2
            3 4 5
            6 7 8
    """

    def __init__(self):
        """
        The rotate pattern puts: the item originally in cell 6 into cell 0
                                 the item originally in cell 3 into cell 1
                                 the item originally in cell 0 into cell 2
                                 etc.
        In other words, it rotates the board 90 degrees clockwise.
        The flip pattern flips the board horizontally about its center column.
        See transformAux() to see these patterns in action.

        0 to 3 rotates and  0 or 1 flip generates all the equivalent boards.
        See representative() to see how all the equivalent boards are generated.
        """
        self.rotatePattern = [6, 3, 0,
                              7, 4, 1,
                              8, 5, 2]
        self.flipPattern = [2, 1, 0,
                            5, 4, 3,
                            8, 7, 6]

    @staticmethod
    def applyPattern(board, pattern):
        return [board[i] for i in pattern]

    def representative(self, board):
        """
        Generate the equivalence class of boards and select the lexicographically smallest.
        :param board:
        :return: (board, rotations, flips); rotations will be in range(4); flips will be in range(2)
                 The rotations and flips are returned so that they can be undone later.
        """
        sortedTransformation = sorted([(self.transform(board, r, f), r, f) for r in range(4) for f in range(2)])
        return sortedTransformation[0]

    def restore(self, board, r, f):
        """
        Unflip and then unrotate the board
        :param board:
        :param r:
        :param f:
        :return:
        """
        # unflipping is the same as flipping a second time.
        unflipped = self.transformAux(board, self.flipPattern, f)
        # unrotating is the same as rotating 4 - r times.
        unrotateedAndFlipped = self.transformAux(unflipped, self.rotatePattern, 4 - r)
        return unrotateedAndFlipped

    def reverseTransformMove(self, move, r, f):
        """
        Unflip and then unrotate the move position.
        :param move:
        :param r:
        :param f:
        :return:
        """
        board = list('_' * 9)
        board[move] = 'M'
        restoredBoard = self.restore(board, r, f)
        nOrig = restoredBoard.index('M')
        return nOrig

    def transform(self, board, r, f):
        """
        Perform r rotations and then f flips on the board
        :param board:
        :param r: number of rotations
        :param f: number of flips
        :return: the rotated and flipped board
        """
        rotated = self.transformAux(board, self.rotatePattern, r)
        rotatedAndFlipped = self.transformAux(rotated, self.flipPattern, f)
        return rotatedAndFlipped

    def transformAux(self, board, pattern, n):
        """
        Rotate or flip the board (according to the pattern) n times.
        :param board:
        :param pattern:
        :param n:
        :return: the transformed board
        """
        if n == 0:
            return board
        else:
            return self.transformAux(self.applyPattern(board, pattern), pattern, n - 1)


if __name__ == '__main__':
    gameManager = GameManager(HumanPlayer, WinsAndBlocksPlayer)
    gameManager.main()


