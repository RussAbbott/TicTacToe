
from random import choice
from typing import Any, AnyStr, Dict, List, NoReturn, Optional, Union

EMPTYCELL: AnyStr = '.'
NEWBOARD: AnyStr = EMPTYCELL * 9

XMARK: AnyStr = 'X'
OMARK: AnyStr = 'O'

CORNERS: List[int] = [0, 2, 6, 8]
CENTER:int = 4
SIDES: List[int] = [1, 3, 5, 7]

def getColAt(move: int) -> List[int]:
    """
    Return a list of the indices for the column that includes move.
    :param move:
    :return:
    """
    colStart = move % 3
    col = [colStart, colStart + 3, colStart + 6]
    return col

def getRowAt(move: int) -> List[int]:
    """
    Return a list of the indices for the row that includes move.
    :param move:
    :return:
    """
    rowStart = (move // 3) * 3
    row = [rowStart, rowStart + 1, rowStart + 2]
    return row

majDiag = [0, 4, 8]
minDiag = [2, 4, 6]

# These are the eight three-element sequences that could make a win.
possibleWinners: List[List[int]] = [majDiag, minDiag,
                                    getRowAt(0), getRowAt(3), getRowAt(6),
                                    getColAt(0), getColAt(1), getColAt(2)]


# Alpha is the learning rate. It declines with more games.
# Select the function for alpha, which is based on player, and return alpha for a given n (game number)
# noinspection PyShadowingNames
def alpha(pctTrained: float, playerMark: AnyStr) -> float:
    alpha_fn = {'X': lambda: min(0.5, pow(0.99, 250 * pctTrained)),
                'O': lambda: min(0.75, pow(0.99, 200 * pctTrained))}[playerMark]
    return alpha_fn()

def argmax(aDict: Dict) -> Any:
    bestKeys = argmaxList(aDict)
    return choice(bestKeys)

def argmaxList(aDict: Dict) -> [Any]:
    bestVal = max(aDict.values())
    bestKeys = [key for (key, val) in aDict.items() if val == bestVal]
    return bestKeys

def formatBoard(board: AnyStr) -> str:
    boardString = \
        '\n'.join([' | '.join(board[0:3]), "--+---+---", ' | '.join(board[3:6]), "--+---+--", ' | '.join(board[6:9])])
    return boardString

# Gamma is the discount rate for future results.
def gamma(playerMark: AnyStr) -> float:
    return {'X': 0.9, 'O': 0.95}[playerMark]

def isAvailable(board: AnyStr, pos: int) -> bool:
    return board[pos] == EMPTYCELL

def marksAtIndices(board: AnyStr, indices: List[int]) -> List[AnyStr]:
    if type(indices) == str:
        print(indices)
    marks = [board[x] for x in indices]
    return marks

def oppositeCorner(pos: int) -> int:
    return {0: 8, 2: 6, 6: 2, 8: 0}[pos]

def otherMark(mark: AnyStr) -> AnyStr:
    return {'X': 'O', 'O': 'X'}[mark]

def render(board: AnyStr) -> NoReturn:
    print(formatBoard(board))

def roundDict(dct: Dict[Any, float]) -> Dict[Any, float]:
    roundedDict = {k: round(v, 2) for (k, v) in dct.items()}
    return roundedDict

def setMove(board: AnyStr, move: int, mark: AnyStr) -> AnyStr:
    """
    Puts mark at position move in board. Works even if move is (max) 8. board[9:] is ''
    Since strings are immutable, a copy is made.
    :param board:
    :param move:
    :param mark:
    :return: the updated board
    """
    return board[0:move] + mark + board[move+1:]

def theWinner(board: AnyStr) -> Optional[AnyStr]:
    """
    Is there a winner? If so return it. Otherwise, return None.
    """
    for triple in possibleWinners:
        [a, b, c] = marksAtIndices(board, triple)
        if a == b == c != EMPTYCELL:
            return a
    return None

def validMoves(board: AnyStr) -> List[int]:
    valids = [i for i in range(9) if isAvailable(board, i)]
    return valids

def weightedAvg(low: Union[float, int], weight: float, high: Union[float, int]) -> float:
    return (1 - weight) * low + weight * high

def whichMarkToMove(board: AnyStr) -> AnyStr:
    return OMARK if board.count(XMARK) > board.count(OMARK) else XMARK



