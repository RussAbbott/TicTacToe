
from itertools import zip_longest
# noinspection PyUnresolvedReferences
from players import HardWiredPlayer, HumanPlayer, LearningPlayer, MinimaxPlayer, Player, WinsBlocksCornersPlayer
from typing import AnyStr, ClassVar, Dict, NoReturn, Optional
from utils import EMPTYCELL, NEWBOARD, XMARK, OMARK, formatBoard, render, setMove, theWinner, whichMarkToMove

class GameManager:

    def __init__(self) -> None:
        self.X: Dict[AnyStr, Optional[AnyStr, float, Player]] = None
        self.O: Dict = None

    # noinspection PyTypeChecker
    def mainLoop(self, isATestGame=True) -> (Dict, AnyStr):
        board = NEWBOARD

        # X always makes the first move.
        (currentPlayer, done, winner) = (self.X, False, None)
        while not done:
            reward = currentPlayer['cachedReward']
            assert reward is None or abs(reward) < 100, f'reward: {reward}; board: {board}'
            move = currentPlayer['player'].makeAMove(currentPlayer['cachedReward'], board, isATestGame)
            # move = currentPlayer['player'].makeAMove(currentPlayerReward, board)
            (done, winner, board) = self.step(board, move)
            assert bool(done) == bool(winner) or bool(done) and board.count(EMPTYCELL) == 0, f'done: {done}; winner: {winner}'
            # assert bool(done) if abs(currentPlayerReward)==100 else True, f'done: {done}; currentPlayerReward: {currentPlayerReward}'
            currentPlayer = self.otherPlayer(currentPlayer)

        # Tell the players the final reward for the game.
        currentPlayer['player'].finalReward(currentPlayer['cachedReward'])
        otherPlayer = self.otherPlayer(currentPlayer)
        otherPlayer['player'].finalReward(otherPlayer['cachedReward'])
        return (winner, board)

    def markToPlayer(self, mark: AnyStr) -> Dict:
        return self.X if mark is XMARK else self.O

    def otherPlayer(self, aPlayer: Dict) -> Dict:
        player = self.O if aPlayer is self.X else self.X
        return player

    def playAGame(self, xPlayerClass: ClassVar, oPlayerClass: ClassVar, isATestGame: bool=True) -> (AnyStr, AnyStr):
        self.reset(xPlayerClass, oPlayerClass)
        (winner, finalBoard) = self.mainLoop(isATestGame)
        result1 = f'{self.X["player"].typeName} (X) vs {self.O["player"].typeName} (O).\n'
        result2 = 'Tie game.' if winner is None else f'{winner["mark"]} ({winner["player"].typeName}) wins.'
        result = result1 + result2
        if HumanPlayer in [type(self.X['player']), type(self.O['player'])]:
            print('\n\n' + result)
            render(finalBoard)
        return (finalBoard, result)

    def printReplay(self, finalBoard: AnyStr, result: AnyStr) -> NoReturn:
        xMoves = self.X['player'].sarsList
        oMoves = self.O['player'].sarsList
        print(f'\n\nReplay: {self.X["player"].typeName} (X) vs {self.O["player"].typeName} (O)')
        # xMoves will be one longer than oMoves unless O wins. Make an extra oMove (None, None, None) if necessary.
        zippedMoves = list(zip_longest(xMoves, oMoves, fillvalue=(None, None, None, None)))
        for xoMoves in zippedMoves:
            ((xBoard, xMove, _, _), (oBoard, oMove, _, _)) = xoMoves
            # Don't print the initial empty board.
            print("" if xBoard == NEWBOARD else formatBoard(xBoard) + "\n", f'\nX -> {xMove}')
            if oBoard is not None:
                print(f'{formatBoard(oBoard)}\n\nO -> {oMove}')
        print(f'{formatBoard(finalBoard)}\n{result}')

    def reset(self, xPlayerClass: ClassVar, oPlayerClass: ClassVar) -> NoReturn:
        xPlayer = xPlayerClass(XMARK)
        oPlayer = oPlayerClass(OMARK)
        self.X = {'mark': XMARK, 'cachedReward': None, 'player': xPlayer}
        self.O = {'mark': OMARK, 'cachedReward': None, 'player': oPlayer}
        xPlayer.reset()
        oPlayer.reset()

    def step(self, board: AnyStr, move: int) -> (bool, AnyStr, AnyStr):
        """
        Make the move and return (done, winner). If no winner, winner will be None.
        :param board:
        :param move:
        :return: (done, winner)
        """
        currentPlayer = self.whoseTurn(board)
        otherPlayer = self.otherPlayer(currentPlayer)

        # The following are all game-ending cases.
        done = True
        if board[move] is not EMPTYCELL:
            # Illegal move. currentPlayer loses.
            currentPlayer['cachedReward'] = -100
            otherPlayer['cachedReward'] = 100
            # (currentPlayerReward, otherPlayerReward) = (-100, 100)
            print(f'\n\nInvalid move by {currentPlayer["mark"]}: {move}.', end='')
            return (done, otherPlayer, board)

        updatedBoard = setMove(board, move, currentPlayer['mark'])
        if theWinner(updatedBoard):
            # The current move won the game.
            currentPlayer['cachedReward'] = 100
            otherPlayer['cachedReward'] = -100
            # (currentPlayerReward, otherPlayerReward) = (100, -100)
            return (done, currentPlayer, updatedBoard)

        if updatedBoard.count(EMPTYCELL) == 0:
            # The game is over. It's a tie.
            currentPlayer['cachedReward'] = 0
            otherPlayer['cachedReward'] = 0
            # (currentPlayerReward, otherPlayerReward) = (0, 0)
            return (done, None, updatedBoard)

        # The game is not over.
        done = False
        # Get a reward for extending the game.
        currentPlayer['cachedReward'] = 1
        # (currentPlayerReward, otherPlayerReward) = (1, None)
        return (done, None, updatedBoard)

    def whoseTurn(self, board: AnyStr) -> Dict:
        mark = whichMarkToMove(board)
        player = self.markToPlayer(mark)
        return player


if __name__ == '__main__':
    gameManager = GameManager( )
    gameManager.playAGame(HumanPlayer, WinsBlocksCornersPlayer)


